import pandas as pd
import glob

# 定义原始列名和目标列名的顺序
original_columns = ['Time', 'V', 'theta', 'psi', 'lamda', 'phi', 'r', 'alpha', 'sigma']
target_columns = ['Time', 'V', 'lamda', 'phi', 'r', 'psi', 'theta', 'alpha', 'sigma']


# 获取所有需要处理的Excel文件
excel_files = glob.glob('output[6-8]-ode1.xlsx')

# 处理每个文件
for file in excel_files:
    # 读取Excel文件
    df = pd.read_excel(file)
    
    # 确保列名匹配
    df.columns = original_columns
    
    # 重新排列列的顺序
    df = df[target_columns]
    
    # 重命名列以匹配要求
    column_mapping = {
        'Time': 't',
        'V': 'v',
        'lamda': 'lambda'
    }
    df = df.rename(columns=column_mapping)
    
    # 生成输出文件名
    output_filename = file.replace('.xlsx', '-processed.csv')
    
    # 保存为CSV文件
    df.to_csv(output_filename, index=False)
    print(f"已处理 {file} 并保存为 {output_filename}")
